DxD VN Engine 0.1.4 — Android PWA package

WHAT THIS FIXES
- Adds a web app manifest configured for fullscreen display and landscape orientation.
- Adds a service worker to cache the app shell for offline relaunch after the first successful visit.
- Keeps the game interface free of the old top and bottom bars.
- Improves dialogue panel height, padding and text line spacing to prevent clipping.
- Does not create a portrait layout or a rotate-phone screen.

IMPORTANT ANDROID LIMITATION
A downloaded HTML file opened through content:// cannot reliably hide the browser/document-viewer controls. A web app manifest and service worker also do not work from a local file. The app must first be hosted on an HTTPS origin, then installed from Chrome. The manifest requests display: fullscreen and orientation: landscape. Android/browser policy may still vary by device and launcher; the app cannot forcibly hide Android system UI from every context.

INSTALL ON ANDROID (FREE)
1. Extract this ZIP.
2. Upload the CONTENTS of this folder (index.html, manifest.webmanifest, sw.js, icons/) to a new GitHub repository. Do not upload the ZIP as a single file.
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
5. Wait for GitHub Pages to publish the HTTPS address.
6. Open that HTTPS address in Chrome on Android.
7. Use Chrome menu > Install app (or Add to Home screen, depending on Chrome version).
8. Launch DxD VN from its new home-screen icon and keep the phone in landscape.
9. Open it once while online so the service worker can cache the app shell. Then test offline mode.

If Chrome only offers Add to Home screen rather than Install app, use it and test the launch. Fullscreen PWA support varies by Android version and browser.

LOCAL TESTING
A PWA cannot be properly installed from file:// or content://. For desktop testing, run a local HTTPS server or use a development server. For Android, GitHub Pages is the simplest free route.

DATA
Prototype save slots currently use browser localStorage. Keep using the same installed app origin and avoid clearing site data. Export/backup functionality will be added in a later engine milestone.

This is a prototype, not the complete visual novel engine. The current scene artwork and story are placeholders for engine testing.
